
// Música toca automaticamente (já está configurado no HTML)
console.log("Site carregado com sucesso.");
